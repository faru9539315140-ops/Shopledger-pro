# ShopLedger V3 — Native Android foundation

This repository starts the native Android rewrite of ShopLedger. It is an Android app project built with Kotlin and Jetpack Compose; it does not open Chrome or wrap the old website.

## Project status

- [x] Native Android project structure and launcher activity
- [x] Initial ShopLedger home screen and module placeholders
- [ ] Migrate V2 business logic: dashboard, sales, purchases, inventory, journal, GST and reports
- [ ] Add Firebase Authentication (Google sign-in)
- [ ] Add Firestore cloud data sync across devices
- [ ] Add offline-first local storage and safe sync conflict handling
- [ ] Test APK on Android devices

## Firebase setup required before building

1. Create a Firebase project.
2. Add an Android app with package name `com.shopledger.app`.
3. Enable Google sign-in in Firebase Authentication.
4. Create a Cloud Firestore database.
5. Download `google-services.json` and place it in `app/google-services.json`.

Do not commit `google-services.json` or private credentials to a public repository. The file is ignored by `.gitignore`.

## Build

Open this folder in Android Studio, allow Gradle sync, then build the `app` debug APK. Android Studio / Android SDK is required; this starter has not yet been built or device-tested.

## Important

This is a starter foundation, not a completed accounting app. The module cards are placeholders until the V2 functions are migrated and tested. Firebase dependencies are included, but authentication and cloud sync are not wired up yet.
