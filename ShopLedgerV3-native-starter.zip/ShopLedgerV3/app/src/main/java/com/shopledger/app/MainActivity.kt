package com.shopledger.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShopLedgerApp() }
    }
}

private val Forest = Color(0xFF245B4A)
private val Page = Color(0xFFF5F7F5)

@Composable
fun ShopLedgerApp() {
    MaterialTheme(colorScheme = lightColorScheme(primary = Forest, background = Page)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Page) {
            Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
                Text("ShopLedger", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Forest)
                Text("Your business, organised.", color = Color(0xFF66736B), fontSize = 14.sp)
                Spacer(Modifier.height(24.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Forest)
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Welcome to ShopLedger V3", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text("Native Android foundation is ready. Sign-in and cloud sync will be connected next.", color = Color.White.copy(alpha = 0.88f), fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("BUSINESS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF66736B))
                Spacer(Modifier.height(10.dp))
                val modules = listOf(
                    "Dashboard" to "Overview and totals",
                    "Sales" to "Invoices and sales register",
                    "Purchases" to "Purchase records",
                    "Inventory" to "Products and stock",
                    "Journal" to "Accounting entries",
                    "GST & Reports" to "Tax summaries and reports"
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(bottom = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(modules) { module ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(module.first, fontWeight = FontWeight.SemiBold, color = Forest, fontSize = 15.sp)
                                Spacer(Modifier.height(5.dp))
                                Text(module.second, color = Color(0xFF718078), fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
